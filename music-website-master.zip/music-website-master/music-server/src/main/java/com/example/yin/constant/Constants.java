package com.example.yin.constant;

public class Constants {
    // MAC、Linux系统
    public static final String RESOURCE_MAC_PATH = "/Users/hongweiyin/Documents/github-workspace/music-website/music-server";

    // windos系统
    public static final String RESOURCE_WIN_PATH = "C:\\Users\\hongweiyin\\Documents\\github-workspace\\music-website\\music-server";
}
