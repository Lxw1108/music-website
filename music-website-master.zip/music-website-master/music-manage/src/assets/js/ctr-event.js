import Vue from 'vue'

const _ctrEvent = new Vue()

export default _ctrEvent
