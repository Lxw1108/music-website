const ICON = {
  BOFANG: '#icon-bofanganniu', // 播放
  ZANTING: '#icon-zanting' // 暂停
}

export {
  ICON
}
