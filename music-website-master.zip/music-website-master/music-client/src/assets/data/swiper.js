// 轮播图
const swiperList = [{
  picImg: require('@/assets/img/swiper/blur-1851426_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/concert-768722_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/boy-984293_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/ipad-605439_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/microphone-1209816_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/music-notes-3221097_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/piano-1655558_640.jpg')
}, {
  picImg: require('@/assets/img/swiper/turntable-1337986_640.jpg')
}]

export {
  swiperList
}
