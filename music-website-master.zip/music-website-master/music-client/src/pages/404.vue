<template>
  <div class="error-page">
    <div class="error-code">404</div>
  </div>
</template>

<script>
export default {
  name: 'error-page'
}
</script>

<style lang="scss" scoped>
@import '../assets/css/404.scss';
</style>
